# ADS_assignments
Assignments for ADS. Group CS-2103S, Noyan Tendikov.
